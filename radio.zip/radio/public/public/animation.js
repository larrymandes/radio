function showSignalMessage() {
    const messageElement = document.createElement('div');
    messageElement.id = 'signalMessage';
    messageElement.innerHTML = 'Received <span style="color: #ff5555;">unknown</span> signal...';
    messageElement.style.position = 'fixed';
    messageElement.style.bottom = '20px'; 
    messageElement.style.left = '50%';
    messageElement.style.transform = 'translateX(-50%)';
    messageElement.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    messageElement.style.color = 'white';
    messageElement.style.padding = '10px';
    messageElement.style.borderRadius = '5px';
    document.body.appendChild(messageElement);

    const loader = document.createElement('div');
    loader.id = 'loader';
    loader.style.position = 'fixed';
    loader.style.bottom = '50px'; 
    loader.style.left = '50%';
    loader.style.transform = 'translateX(-50%)';
    loader.style.fontSize = '24px';
    loader.style.color = 'white';
    loader.innerText = '/ | \\';
    document.body.appendChild(loader);

    let loaderIndex = 0;
    setInterval(() => {
        loader.innerText = ['/', '|', '\\'][loaderIndex];
        loaderIndex = (loaderIndex + 1) % 3;
    }, 300); 
}

function hideSignalMessage() {
    const messageElement = document.getElementById('signalMessage');
    if (messageElement) {
        messageElement.remove();
    }
    const loader = document.getElementById('loader');
    if (loader) {
        loader.remove();
    }
}
