const outputDiv = document.getElementById('output');
const inputField = document.getElementById('input');
const audioContext = new (window.AudioContext || window.webkitAudioContext)();
let silenceBuffer;
let currentSource;
let listening = false; 


function createSilence(duration) {
    silenceBuffer = audioContext.createBuffer(1, audioContext.sampleRate * duration, audioContext.sampleRate);
    const channelData = silenceBuffer.getChannelData(0);
    for (let i = 0; i < channelData.length; i++) {
        channelData[i] = 0; 
    }
}


function playSilence() {
    currentSource = audioContext.createBufferSource();
    currentSource.buffer = silenceBuffer;
    currentSource.loop = true; 
    currentSource.connect(audioContext.destination);
    currentSource.start(0);
}


function createEqualizer() {
    const filters = [];
    const gains = [
        9.6, 9.1, 9.1, 9.1, 9.1, 9.1, 9.1, 9.1,
        5.1, 7.8, 3.9, 2.6, 0, 0, 0, 0,
        20, 20, 0, 0, 0, 0, 0, 0,
        0, 0, 0
    ];

    const frequencies = [
        20, 25, 31.5, 40, 50, 63, 80, 100, 200, 250, 315, 400,
        500, 630, 800, 1000, 2000, 2500, 3150, 4000, 5000,
        6300, 8000, 10000, 12500, 16000, 20000
    ];

    for (let i = 0; i < frequencies.length; i++) {
        let filter = audioContext.createBiquadFilter();
        filter.type = 'peaking'; 
        filter.frequency.setValueAtTime(frequencies[i], audioContext.currentTime);
        filter.gain.setValueAtTime(gains[i], audioContext.currentTime); 
        filters.push(filter);
    }

    return filters;
}


function applyEffects(audioBuffer, audioUrl) {
    const filters = createEqualizer();
    
    currentSource = audioContext.createBufferSource();
    currentSource.buffer = audioBuffer;

    const gainNode = audioContext.createGain();
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);

    currentSource.connect(filters[0]);
    for (let i = 0; i < filters.length - 1; i++) {
        filters[i].connect(filters[i + 1]);
    }
    filters[filters.length - 1].connect(gainNode);
    gainNode.connect(audioContext.destination);

    currentSource.start(0);

    currentSource.onended = function() {
        playSilence();
        hideSignalMessage();

        // Отправляем запрос на удаление аудиофайла
        fetch('/delete-audio', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ audioUrl }),
        })
        .then(response => {
            if (response.ok) {
                console.log('Аудиофайл успешно удалён.');
            } else {
                console.error('Ошибка при удалении аудиофайла.');
            }
        })
        .catch(err => console.error('Ошибка при удалении аудиофайла:', err));
    };
}

    


document.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        const command = inputField.value.trim();
        outputDiv.innerHTML += `[root@user ~]# ${command}\n`; 

        if (command === 'listen' && !listening) {
            listening = true; 
            outputDiv.innerHTML += "Starting to listen...\n";
            audioContext.resume().then(() => {
                createSilence(10);
                playSilence(); 
            });
        } else if (command === 'listen' && listening) {
            outputDiv.innerHTML += "You are already in listening mode.\n";
        } else {
            outputDiv.innerHTML += "<span class='error'>Unknown command.</span>\n"; 
        }

        inputField.value = ''; 
    }
});

const socket = new WebSocket('ws://localhost:3000');

socket.onmessage = function(event) {
    const audioUrl = event.data;

    if (currentSource) {
        currentSource.stop();
    }

    fetch(audioUrl)
        .then(response => response.arrayBuffer())
        .then(arrayBuffer => audioContext.decodeAudioData(arrayBuffer))
        .then(audioBuffer => {
            if (listening) {
                applyEffects(audioBuffer, audioUrl); // Передаем audioUrl
                showSignalMessage();
            }
        })
        .catch(err => console.error('Ошибка', err));
};
